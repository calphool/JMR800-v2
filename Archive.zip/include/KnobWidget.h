#include "Widget.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

class KnobWidget : public Widget {
public:
    KnobWidget(Adafruit_SH1106G* display, int _x, int _y);


protected:
    Adafruit_SH1106G* display;
    void drawBezel();
};

