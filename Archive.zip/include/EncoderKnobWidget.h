#include "KnobWidget.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>


class EncoderKnobWidget : public KnobWidget {
public:
    EncoderKnobWidget(Adafruit_SH1106G* display, int x, int y);

    void setPressed(bool state);
    void draw() override;

private:
    bool pressed;
};


