#include "KnobWidget.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

class PotentiometerKnobWidget : public KnobWidget {
public:
    PotentiometerKnobWidget(Adafruit_SH1106G* display, int knobId, int x, int y);

    void setValue(uint8_t value);         // 0–255 (mapped to degrees)
    void setHighlighted(bool highlight);  // blinking only when highlighted

    void draw() override;

private:
    int knobId;
    uint8_t value;
    bool highlighted;
    bool blinkState;

    void drawArrow(int deg);
};