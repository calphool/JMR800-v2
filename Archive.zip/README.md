# JMR800-v2
Complete rewrite of JMR800 codebase to make it more modular and sustainable

For now, see the readme.md of the JMR800 project to get an understanding of this code.  Eventually this will become the main repo, and the other one will become 
deprecated.
