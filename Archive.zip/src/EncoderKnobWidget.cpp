#include "EncoderKnobWidget.h"

EncoderKnobWidget::EncoderKnobWidget(Adafruit_SH1106G* display, int x, int y)
    : KnobWidget(display, x, y), pressed(false) {}

void EncoderKnobWidget::setPressed(bool p) {
    pressed = p;
}

void EncoderKnobWidget::draw() {
    display->fillRect(x+2, y+1, 6, 4, pressed ? SH110X_BLACK : SH110X_WHITE);
    drawBezel();
}
