#include "KnobWidget.h"

KnobWidget::KnobWidget(Adafruit_SH1106G* display, int x, int y)
    : Widget(x, y), display(display) {
    }

void KnobWidget::drawBezel() {
    display->drawLine(x+3, y,   x+6, y,   SH110X_WHITE);
    display->drawLine(x+3, y+5, x+6, y+5, SH110X_WHITE);
    display->drawLine(x+1, y+2, x+1, y+3, SH110X_WHITE);
    display->drawLine(x+8, y+2, x+8, y+3, SH110X_WHITE);
}
