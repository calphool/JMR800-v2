#include "PotentiometerKnobWidget.h"
#include "globals.h"  // arrow_dx, arrow_dy

PotentiometerKnobWidget::PotentiometerKnobWidget(Adafruit_SH1106G* display, int knobId, int x, int y)
    : KnobWidget(display, x, y), knobId(knobId),
      value(0), highlighted(false), blinkState(true) {}

void PotentiometerKnobWidget::setValue(uint8_t v) {
    value = v;
}

void PotentiometerKnobWidget::setHighlighted(bool h) {
    highlighted = h;
}

void PotentiometerKnobWidget::drawArrow(int deg) {
    int cx = x + 4;
    int cy = y + 3;

    deg = (deg - 45 + 360) % 360;
    int index = deg % 360;

    int ex = cx + arrow_dx[index];
    int ey = cy + arrow_dy[index];

    display->drawLine(cx, cy, ex, ey, SH110X_BLACK);
}

void PotentiometerKnobWidget::draw() {
    if (highlighted) {
        blinkState = !blinkState;
    }

    bool fillBlack = highlighted && blinkState;

    display->fillRect(x+2, y+1, 6, 4, fillBlack ? SH110X_BLACK : SH110X_WHITE);

    drawBezel();

    if (value != 255) {
        int deg = static_cast<int>((360.0f * value) / 255.0f);
        drawArrow(deg);
    }
}
